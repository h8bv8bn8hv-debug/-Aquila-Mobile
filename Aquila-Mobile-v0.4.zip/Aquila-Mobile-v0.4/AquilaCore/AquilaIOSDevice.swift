import Foundation
import UIKit

public struct AquilaIOSDevice {
    public init() {}

    public func snapshot() -> AquilaDeviceSnapshot {
        let d = UIDevice.current
        return AquilaDeviceSnapshot(
            model: d.model,
            systemName: d.systemName,
            systemVersion: d.systemVersion,
            identifier: d.identifierForVendor?.uuidString ?? "unknown"
        )
    }
}

public struct AquilaDeviceSnapshot: Sendable {
    public let model: String
    public let systemName: String
    public let systemVersion: String
    public let identifier: String
}
