import Foundation

public struct AquilaCore {
    public static let version = "0.4.0"
    public init() {}

    public func iniciar() -> String {
        "🦅 AQUILA CORE v\(Self.version) — listo"
    }
}
