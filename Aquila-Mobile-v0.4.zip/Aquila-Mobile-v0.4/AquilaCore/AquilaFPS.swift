import Foundation

public enum AquilaFPSTarget: Int, CaseIterable, Sendable {
    case fps30 = 30, fps40 = 40, fps50 = 50, fps60 = 60, fps90 = 90, fps120 = 120, fps144 = 144
    case unlimited = 0

    public var label: String { rawValue == 0 ? "Ilimitado" : "\(rawValue) FPS" }
}
