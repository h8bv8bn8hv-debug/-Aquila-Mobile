import Foundation

public enum AquilaVisualPriority: String, Sendable { case ui, player, importantGeometry, world, particles, transparency, background }

public struct AquilaSceneBudget: Sendable {
    public let ui: Double
    public let player: Double
    public let geometry: Double
    public let effects: Double
    public let background: Double

    public init(thermal: AquilaThermalState, level: AquilaReconstructionLevel) {
        let aggressive = level == .x3 || level == .x4 || thermal == .serious || thermal == .critical
        ui = 1.0; player = 1.0; geometry = aggressive ? 0.80 : 0.95
        effects = aggressive ? 0.70 : 0.90; background = aggressive ? 0.55 : 0.80
    }
}
