import Foundation

public struct AquilaProfile: Sendable {
    public let target: AquilaFPSTarget
    public let quality: AquilaQuality
    public let control: AquilaControlMode
    public let reconstruction: AquilaReconstructionLevel
}
