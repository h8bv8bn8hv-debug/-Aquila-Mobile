import Foundation

public struct AquilaPerformance {
    public let target: AquilaFPSTarget
    public let measuredFPS: Double?
    public let thermal: AquilaThermalState

    public init(target: AquilaFPSTarget, measuredFPS: Double? = nil, thermal: AquilaThermalState = .unknown) {
        self.target = target; self.measuredFPS = measuredFPS; self.thermal = thermal
    }

    public var deficit: Double {
        guard target.rawValue > 0, let measuredFPS else { return 0 }
        return max(0, Double(target.rawValue) - measuredFPS)
    }
}
