import Foundation

public struct AquilaTelemetrySettings: Sendable {
    public var enabled: Bool
    public init(enabled: Bool = false) { self.enabled = enabled }
}

public struct AquilaTelemetryEvent: Sendable {
    public let fps: Double?
    public let thermal: AquilaThermalState
    public let reconstruction: AquilaReconstructionLevel
    public let error: String?
}
