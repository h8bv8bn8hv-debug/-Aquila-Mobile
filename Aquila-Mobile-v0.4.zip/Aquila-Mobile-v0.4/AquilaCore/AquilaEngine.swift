import Foundation

public struct AquilaEngine {
    public static let version = "0.4.0"
    public init() {}

    public func run(target: AquilaFPSTarget = .fps60,
                    quality: AquilaQuality = .high,
                    control: AquilaControlMode = .recommended) -> AquilaControllerResult {
        AquilaController().buildPlan(target: target, quality: quality, control: control)
    }
}
