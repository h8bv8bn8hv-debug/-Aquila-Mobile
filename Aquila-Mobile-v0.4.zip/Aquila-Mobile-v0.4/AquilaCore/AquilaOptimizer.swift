import Foundation

public struct AquilaOptimizer {
    public init() {}

    public func optimize(profile: AquilaHardwareProfile, decision: AquilaDecision) -> AquilaOptimizationPlan {
        let level = decision.decide()
        let scale: Double
        switch level { case .x1: scale = 1.0; case .x2: scale = 0.85; case .x3: scale = 0.70; case .x4: scale = 0.58 }
        let thermalGuard = decision.thermal == .serious || decision.thermal == .critical
        return AquilaOptimizationPlan(
            reconstruction: level,
            internalScale: scale,
            thermalGuard: thermalGuard,
            protectUI: true,
            prioritizeImportantGeometry: true
        )
    }
}

public struct AquilaOptimizationPlan: Sendable {
    public let reconstruction: AquilaReconstructionLevel
    public let internalScale: Double
    public let thermalGuard: Bool
    public let protectUI: Bool
    public let prioritizeImportantGeometry: Bool
}
