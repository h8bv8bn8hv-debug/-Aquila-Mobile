import Foundation

public enum AquilaCompatibility: String, Sendable {
    case full = "🟢 Completa"
    case limited = "🟡 Limitada"
    case monitorOnly = "⚪ Solo monitorización"
    case unsupported = "🔴 No compatible"
}
