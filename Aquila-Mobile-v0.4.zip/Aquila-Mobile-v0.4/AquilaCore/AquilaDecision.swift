import Foundation

public struct AquilaDecision {
    public let target: AquilaFPSTarget
    public let quality: AquilaQuality
    public let control: AquilaControlMode
    public let thermal: AquilaThermalState

    public init(target: AquilaFPSTarget, quality: AquilaQuality, control: AquilaControlMode, thermal: AquilaThermalState = .nominal) {
        self.target = target; self.quality = quality; self.control = control; self.thermal = thermal
    }

    public func decide() -> AquilaReconstructionLevel {
        if control == .manual { return .x1 }
        if thermal == .critical { return .x4 }
        if thermal == .serious { return quality == .ultra ? .x3 : .x4 }
        switch (quality, target.rawValue) {
        case (.ultra, 0...60): return .x1
        case (.ultra, 61...90): return .x2
        case (.ultra, _): return .x3
        case (.high, 0...60): return .x2
        case (.high, 61...90): return .x3
        default: return .x4
        }
    }
}
