import Foundation

public struct AquilaScore {
    public static func calculate(hardware: AquilaHardwareProfile, thermal: AquilaThermalState) -> Int {
        var score = 40
        score += min(20, hardware.cpuCoreCount * 2)
        score += min(20, Int(hardware.physicalMemoryGB * 2))
        score += min(15, Int(hardware.gpuWorkingSetGB * 5))
        if hardware.refreshRate >= 120 { score += 5 }
        if thermal == .serious { score -= 8 }
        if thermal == .critical { score -= 18 }
        return min(100, max(0, score))
    }
}
