import Foundation

public struct AquilaController {
    public init() {}

    public func buildPlan(target: AquilaFPSTarget = .fps60,
                          quality: AquilaQuality = .high,
                          control: AquilaControlMode = .recommended) -> AquilaControllerResult {
        let analysis = AquilaAnalyzer().analyze()
        let decision = AquilaDecision(target: target, quality: quality, control: control, thermal: analysis.thermal)
        let plan = AquilaOptimizer().optimize(profile: analysis.hardware, decision: decision)
        let score = AquilaScore.calculate(hardware: analysis.hardware, thermal: analysis.thermal)
        let budget = AquilaSceneBudget(thermal: analysis.thermal, level: plan.reconstruction)
        return AquilaControllerResult(analysis: analysis, plan: plan, score: score, budget: budget)
    }
}

public struct AquilaControllerResult: Sendable {
    public let analysis: AquilaAnalysisResult
    public let plan: AquilaOptimizationPlan
    public let score: Int
    public let budget: AquilaSceneBudget
}
