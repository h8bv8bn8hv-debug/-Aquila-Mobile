import Foundation
import UIKit

public struct AquilaAnalyzer {
    public init() {}

    public func analyze() -> AquilaAnalysisResult {
        let device = AquilaIOSDevice().snapshot()
        let graphics = AquilaGraphics().snapshot()
        let cores = ProcessInfo.processInfo.activeProcessorCount
        let ramGB = Double(ProcessInfo.processInfo.physicalMemory) / 1_073_741_824.0
        let hardware = AquilaHardwareProfile(
            device: device, gpuName: graphics.gpuName, cpuCoreCount: cores,
            physicalMemoryGB: ramGB, screenWidth: graphics.pixelWidth,
            screenHeight: graphics.pixelHeight, refreshRate: graphics.refreshRate,
            gpuWorkingSetGB: graphics.recommendedWorkingSetGB
        )
        return AquilaAnalysisResult(hardware: hardware, thermal: AquilaThermal().state())
    }
}

public struct AquilaAnalysisResult: Sendable {
    public let hardware: AquilaHardwareProfile
    public let thermal: AquilaThermalState
}
