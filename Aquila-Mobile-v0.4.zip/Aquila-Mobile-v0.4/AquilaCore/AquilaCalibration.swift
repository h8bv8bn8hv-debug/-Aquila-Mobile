import Foundation

public struct AquilaCalibration {
    public init() {}
    public func levels() -> [AquilaReconstructionLevel] { AquilaReconstructionLevel.allCases }
}
