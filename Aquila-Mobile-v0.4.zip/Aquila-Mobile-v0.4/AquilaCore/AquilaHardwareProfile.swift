import Foundation

public struct AquilaHardwareProfile: Sendable {
    public let device: AquilaDeviceSnapshot
    public let gpuName: String
    public let cpuCoreCount: Int
    public let physicalMemoryGB: Double
    public let screenWidth: Int
    public let screenHeight: Int
    public let refreshRate: Int
    public let gpuWorkingSetGB: Double

    public var estimatedClass: String {
        let score = Double(cpuCoreCount) + physicalMemoryGB + gpuWorkingSetGB * 2
        if score >= 30 { return "High" }
        if score >= 20 { return "Mid" }
        return "Entry"
    }
}
