import Foundation
import UIKit

public enum AquilaThermalState: String, Sendable { case nominal, fair, serious, critical, unknown }

public struct AquilaThermal {
    public init() {}
    public func state() -> AquilaThermalState {
        switch ProcessInfo.processInfo.thermalState {
        case .nominal: return .nominal
        case .fair: return .fair
        case .serious: return .serious
        case .critical: return .critical
        @unknown default: return .unknown
        }
    }
}
