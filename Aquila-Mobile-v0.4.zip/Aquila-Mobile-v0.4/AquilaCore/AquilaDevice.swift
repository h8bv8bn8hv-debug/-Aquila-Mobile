import Foundation

public struct AquilaDevice {
    public let hardware: AquilaHardwareProfile
    public init(hardware: AquilaHardwareProfile) { self.hardware = hardware }
}
