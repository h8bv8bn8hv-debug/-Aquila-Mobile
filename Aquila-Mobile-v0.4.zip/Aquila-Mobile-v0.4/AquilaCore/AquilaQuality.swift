import Foundation

public enum AquilaQuality: String, CaseIterable, Sendable {
    case ultra = "Ultra"
    case high = "Alta"
    case balanced = "Equilibrada"
    case performance = "Rendimiento"
}

public enum AquilaControlMode: String, CaseIterable, Sendable {
    case manual = "Manual"
    case recommended = "Recomendado"
    case automatic = "Automático"
}
