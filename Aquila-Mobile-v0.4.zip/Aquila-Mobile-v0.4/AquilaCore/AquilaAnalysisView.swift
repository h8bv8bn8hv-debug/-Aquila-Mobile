import SwiftUI

public struct AquilaAnalysisView: View {
    @State private var result: AquilaControllerResult?
    @State private var analyzing = false

    public init() {}

    public var body: some View {
        ScrollView {
            VStack(spacing: 18) {
                Text("🦅").font(.system(size: 60))
                Text("ANÁLISIS AQUILA").font(.title2).bold()

                if let result {
                    card("📱 Dispositivo", result.analysis.hardware.device.model)
                    card("🧠 CPU", "\(result.analysis.hardware.cpuCoreCount) núcleos")
                    card("💾 RAM", String(format: "%.1f GB", result.analysis.hardware.physicalMemoryGB))
                    card("🎮 GPU", result.analysis.hardware.gpuName)
                    card("🖥️ Pantalla", "\(result.analysis.hardware.screenWidth) × \(result.analysis.hardware.screenHeight) • \(result.analysis.hardware.refreshRate) Hz")
                    card("🌡️ Térmica", result.analysis.thermal.rawValue)
                    card("⭐ Aquila Score", "\(result.score)/100")
                    card("⚡ Recomendación", "\(result.plan.reconstruction.rawValue) • escala \(Int(result.plan.internalScale * 100))%")
                } else {
                    Text("Aquila todavía no ha analizado este dispositivo.")
                        .foregroundStyle(.secondary).multilineTextAlignment(.center)
                }

                Button(analyzing ? "ANALIZANDO..." : "INICIAR ANÁLISIS") {
                    analyze()
                }
                .font(.headline).padding().frame(maxWidth: .infinity)
                .background(.primary).foregroundStyle(.background)
                .clipShape(RoundedRectangle(cornerRadius: 16))
            }.padding(24)
        }
        .navigationTitle("Aquila")
    }

    private func card(_ title: String, _ value: String) -> some View {
        HStack { Text(title); Spacer(); Text(value).foregroundStyle(.secondary).multilineTextAlignment(.trailing) }
            .padding().background(.gray.opacity(0.12)).clipShape(RoundedRectangle(cornerRadius: 14))
    }

    private func analyze() {
        analyzing = true
        DispatchQueue.global(qos: .userInitiated).async {
            let result = AquilaEngine().run(target: .fps60, quality: .high, control: .recommended)
            DispatchQueue.main.async {
                self.result = result
                self.analyzing = false
            }
        }
    }
}
