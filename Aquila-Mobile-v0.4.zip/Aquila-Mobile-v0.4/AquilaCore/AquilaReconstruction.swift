import Foundation

public enum AquilaReconstructionLevel: String, CaseIterable, Sendable {
    case x1 = "X1", x2 = "X2", x3 = "X3", x4 = "X4"

    public var description: String {
        switch self {
        case .x1: return "Máxima fidelidad y mínima reconstrucción"
        case .x2: return "Equilibrio calidad/rendimiento"
        case .x3: return "Alta eficiencia con reconstrucción fuerte"
        case .x4: return "Máxima eficiencia de reconstrucción"
        }
    }
}

public struct AquilaReconstruction {
    public let level: AquilaReconstructionLevel
    public init(level: AquilaReconstructionLevel) { self.level = level }
}
