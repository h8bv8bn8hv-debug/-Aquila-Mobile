import SwiftUI

public struct AquilaView: View {
    public init() {}
    public var body: some View {
        NavigationStack {
            VStack(spacing: 22) {
                Text("🦅").font(.system(size: 70))
                Text("AQUILA").font(.system(size: 38, weight: .bold))
                Text("v0.4 MOBILE").foregroundStyle(.secondary)
                NavigationLink("🔍 ANALIZAR MI DISPOSITIVO") { AquilaAnalysisView() }
                    .font(.headline).padding().frame(maxWidth: .infinity)
                    .background(.primary).foregroundStyle(.background)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
            }.padding(24)
        }
    }
}
