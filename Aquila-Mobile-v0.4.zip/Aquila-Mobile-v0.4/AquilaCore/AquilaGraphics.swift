import Foundation
import UIKit
import Metal

public struct AquilaGraphics {
    public init() {}

    public func snapshot() -> AquilaGraphicsSnapshot {
        let screen = UIScreen.main
        let native = screen.nativeBounds.size
        let hz = screen.maximumFramesPerSecond
        let metal = MTLCreateSystemDefaultDevice()
        let memoryGB = metal.map { Double($0.recommendedMaxWorkingSetSize) / 1_073_741_824.0 } ?? 0
        let gpuName = metal?.name ?? "GPU no expuesta"
        return AquilaGraphicsSnapshot(
            pixelWidth: Int(native.width), pixelHeight: Int(native.height),
            refreshRate: hz, gpuName: gpuName, recommendedWorkingSetGB: memoryGB
        )
    }
}

public struct AquilaGraphicsSnapshot: Sendable {
    public let pixelWidth: Int
    public let pixelHeight: Int
    public let refreshRate: Int
    public let gpuName: String
    public let recommendedWorkingSetGB: Double
}
