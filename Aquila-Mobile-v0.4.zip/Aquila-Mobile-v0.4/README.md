# 🦅 Aquila Mobile v0.4

Aquila is a game-specific reconstruction and graphics optimization system designed to extract as much visual quality and performance as technically possible from each device.

## v0.4 focus
- Real iOS hardware/runtime inspection where Apple APIs expose the information.
- Hardware-aware optimization decisions.
- X1/X2/X3/X4 reconstruction strategy.
- Quality + FPS target + thermal awareness.
- Scene-intelligence foundation: visual importance and processing budget.
- Aquila Score.
- Calibration model and per-game profiles.
- Optional telemetry model (performance/errors only).
- Compatibility states: full / limited / monitor-only / unsupported.
- Manual, recommended and automatic control philosophies.

## Important
This is a v0.4 engineering foundation, not a finished DLSS replacement and not a GPU driver. iOS sandbox/API rules prevent a normal app from modifying arbitrary third-party games. Real in-game reconstruction requires integration with a supported renderer/game or permitted graphics APIs.

The neural reconstruction models, real temporal GPU kernels, game SDK integration and production benchmarks are future stages.

## Development
The source can be edited from GitHub Codespaces on an iPhone. Building a native iOS app normally requires Xcode on macOS (locally or through a permitted remote Mac service).
