# v0.4 scope and honesty checklist

Implemented foundation:
- Device/runtime inspection through public iOS APIs.
- Metal device name and recommended working-set information.
- CPU core count and physical memory.
- Display resolution and maximum refresh rate.
- Thermal state.
- Hardware-aware recommendation pipeline.
- X1-X4 policy.
- Quality/control modes.
- Scene visual-priority budget.
- Aquila Score.
- Calibration level list.
- Optional telemetry data structures.
- Compatibility states.
- SwiftUI analysis screen showing results.

Not yet implemented:
- A production temporal reconstruction kernel.
- Real motion vectors/depth from arbitrary games.
- Neural rendering models.
- Frame generation.
- Modification of third-party games.
- Direct GPU driver functionality.
- Guaranteed performance improvements.

These require renderer/game integration, Metal compute work, controlled benchmarks and platform permissions.
