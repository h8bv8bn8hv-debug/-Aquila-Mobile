# Aquila v0.4 architecture

Hardware/runtime -> Analyzer -> Decision -> Optimizer -> Profile -> Renderer integration

Supporting systems:
- Thermal guard
- Scene intelligence
- Calibration
- Score
- Compatibility
- Optional telemetry

Aquila never promises a fixed FPS multiplier. Decisions are based on measurable device capability, target FPS, quality preference and thermal state.
