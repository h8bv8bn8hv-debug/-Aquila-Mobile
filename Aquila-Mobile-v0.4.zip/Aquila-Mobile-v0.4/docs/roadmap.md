# Roadmap after v0.4

## v0.5
- Real Metal render path.
- GPU timing and frame pacing.
- Better per-device benchmarks.
- Render-scale controller.

## v0.6
- Motion/depth/reactive inputs.
- Temporal reconstruction kernels.
- Disocclusion handling.
- Particle/transparency handling.

## v0.7+
- Aquila neural models.
- Model selection by device/game/scene.
- Engine SDK.
- A/B quality validation against native and other permitted technologies.

No version should claim superiority over DLSS/FSR/XeSS without controlled benchmarks.
